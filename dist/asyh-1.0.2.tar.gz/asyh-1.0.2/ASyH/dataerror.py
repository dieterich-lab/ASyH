'A simple exception to be raised if data/metadata is in an unrecoverable state'


class DataError(LookupError):
    'A simple exception to be raised if data/metadata is in an unrecoverable state'
