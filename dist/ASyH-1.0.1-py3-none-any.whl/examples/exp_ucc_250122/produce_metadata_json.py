import sdv.metadata as metadata
from ASyH.metadata import Metadata
import json
import pandas as pd
import pdb


INPUT_FILE_CSV = "/home/gsergei/ASyH/examples/exp_ucc_250122/src_holdout_ucc.csv"
OUTPUT_FILE_JSON = "/home/gsergei/ASyH/examples/exp_ucc_250122/metadata_ucc.json"

meta_sdv = metadata.SingleTableMetadata()
meta_sdv.detect_from_csv(INPUT_FILE_CSV)
pdb.set_trace()
meta_dict = meta_sdv.to_dict() # where metadata is stored in dictionary

with open(OUTPUT_FILE_JSON, "w") as meta_file:
    json.dump(meta_dict, meta_file)
